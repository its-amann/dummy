
from fastapi import APIRouter, HTTPException
from app.models import Item
from app.utils.helper import format_response

router = APIRouter(tags=["items"])

# In-memory store
items: list[Item] = []

@router.post("/items/")
async def create_item(item: Item):
    items.append(item)
    return format_response("Item created", data=item.model_dump())

@router.get("/items/{item_name}")
async def get_item(item_name: str):
    for it in items:
        if it.name == item_name:
            return it
    raise HTTPException(status_code=404, detail="Item not found")

@router.get("/items")
async def list_items():
    return items
