
from fastapi import APIRouter, HTTPException
from app.models import User
from app.services.user_service import validate_user
from app.utils.helper import format_response

router = APIRouter(tags=["users"])

# In-memory store
users: list[User] = []

@router.post("/users/")
async def create_user(user: User):
    try:
        validate_user(user)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    users.append(user)
    return format_response("User created", data=user.model_dump())

@router.get("/users/{username}")
async def get_user(username: str):
    for u in users:
        if u.username == username:
            return u
    raise HTTPException(status_code=404, detail="User not found")

@router.get("/users")
async def list_users():
    return users
