
from typing import Any, Optional, Dict

def format_response(message: str, data: Optional[Any] = None) -> Dict[str, Any]:
    return {"message": message, "data": data}
