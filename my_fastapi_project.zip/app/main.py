
from fastapi import FastAPI
from app.api import users, items

app = FastAPI(title="My FastAPI Project")

# Include routers
app.include_router(users.router)
app.include_router(items.router)

@app.get("/", tags=["root"])
def root():
    return {"message": "Welcome to My FastAPI Project"}
