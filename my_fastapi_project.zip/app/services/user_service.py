
from app.models import User

def validate_user(user: User) -> bool:
    """Basic validation logic (can be expanded later).
    Raises ValueError if invalid, returns True if OK.
    """
    if len(user.username) < 3:
        raise ValueError("Username is too short (min 3 characters)")
    if "@" not in user.email:
        raise ValueError("Email must contain '@'")
    return True
