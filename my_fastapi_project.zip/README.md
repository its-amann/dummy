
# My FastAPI Project

## Description
A simple, modular FastAPI application that handles users and items. Built to look like beginner progress while learning the framework.

## Installation

Create a virtual environment and install dependencies:

```bash
python3 -m venv venv
source venv/bin/activate          # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Run the Application

```bash
uvicorn app.main:app --reload
```

Open the interactive docs at **http://127.0.0.1:8000/docs**

## Endpoints
- `POST /users/` - Create a new user
- `GET /users/{username}` - Get user information
- `GET /users` - List all users
- `POST /items/` - Create a new item
- `GET /items/{item_name}` - Get item information
- `GET /items` - List all items

## Notes
- This demo keeps data **in memory** (lists) for simplicity.
- No background tasks, CORS, templates/static files, or auth (as requested).
