
from fastapi.testclient import TestClient
from labs.lab04_crud_in_memory import app

client = TestClient(app)

def test_crud_flow():
    # create
    r = client.post("/todos", json={"title": "learn", "done": False})
    assert r.status_code == 201
    todo = r.json()
    tid = todo["id"]

    # get
    r = client.get(f"/todos/{tid}")
    assert r.status_code == 200
    assert r.json()["id"] == tid

    # update
    r = client.put(f"/todos/{tid}", json={"title": "learn fastapi", "done": True})
    assert r.status_code == 200
    assert r.json()["done"] is True

    # list
    r = client.get("/todos")
    assert r.status_code == 200
    assert any(t["id"] == tid for t in r.json())

    # delete
    r = client.delete(f"/todos/{tid}")
    assert r.status_code == 204
