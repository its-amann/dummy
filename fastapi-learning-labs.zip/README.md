
# FastAPI Learning Labs (Beginner-Friendly)

A set of tiny, focused FastAPI examples that look and feel like a beginner practicing and making progress lesson by lesson.

> **How to run (macOS/Linux):**
>
> ```bash
> python -m venv .venv
> source .venv/bin/activate
> pip install -r requirements.txt
> # Pick any lab to run:
> uvicorn labs.lab01_hello_world:app --reload
> ```
>
> **How to run (Windows PowerShell):**
>
> ```powershell
> py -m venv .venv
> .\.venv\Scripts\Activate.ps1
> pip install -r requirements.txt
> uvicorn labs.lab01_hello_world:app --reload
> ```
>
> Requires **Python 3.10+**.

---

## Labs overview

| Lab | File/Module | What it demonstrates | Example command |
|-----|-------------|----------------------|-----------------|
| 01 | `labs/lab01_hello_world.py` | First endpoint, return JSON | `uvicorn labs.lab01_hello_world:app --reload` |
| 02 | `labs/lab02_path_query.py` | Path / Query params | `uvicorn labs.lab02_path_query:app --reload` |
| 03 | `labs/lab03_pydantic_models.py` | Pydantic models & validation | `uvicorn labs.lab03_pydantic_models:app --reload` |
| 04 | `labs/lab04_crud_in_memory.py` | In-memory CRUD (basic API) | `uvicorn labs.lab04_crud_in_memory:app --reload` |
| 05 | `labs/lab05_dependencies_headers.py` | Dependencies & header validation | `uvicorn labs.lab05_dependencies_headers:app --reload` |
| 06 | `labs/lab06_error_handling.py` | Custom exceptions & handlers | `uvicorn labs.lab06_error_handling:app --reload` |
| 07 | `labs/lab07_background_tasks.py` | BackgroundTasks (e.g., write a log) | `uvicorn labs.lab07_background_tasks:app --reload` |
| 08 | `labs/lab08_cors_middleware.py` | CORS middleware | `uvicorn labs.lab08_cors_middleware:app --reload` |
| 09 | `labs/lab09_file_upload.py` | File upload & saving | `uvicorn labs.lab09_file_upload:app --reload` |
| 10 | `labs/lab10_templates_static.py` | Templates & static files | `uvicorn labs.lab10_templates_static:app --reload` |
| 11 | `labs/lab11_auth_bearer.py` | Simple bearer auth (demo-only) | `uvicorn labs.lab11_auth_bearer:app --reload` |
| 12 | `labs/lab12_websockets.py` | WebSockets echo | `uvicorn labs.lab12_websockets:app --reload` |
| 13 | `labs/lab13_settings_env.py` | Read settings from environment | `uvicorn labs.lab13_settings_env:app --reload` |
| 14 | `labs/lab14_router_structure/main.py` | Modular routers | `uvicorn labs.lab14_router_structure.main:app --reload` |
| 15 | `labs/lab15_ml_stub.py` | Minimal ML-ish predict endpoint | `uvicorn labs.lab15_ml_stub:app --reload` |

---

## Quick demos

### Lab 04 CRUD
```bash
uvicorn labs.lab04_crud_in_memory:app --reload
# create
curl -X POST http://127.0.0.1:8000/todos -H "content-type: application/json" -d '{"title": "learn fastapi", "done": false}'
# list
curl http://127.0.0.1:8000/todos
```

### Lab 05 protected route
```bash
uvicorn labs.lab05_dependencies_headers:app --reload
curl http://127.0.0.1:8000/public
curl -H "X-Token: learnfast" http://127.0.0.1:8000/private
```

### Lab 09 file upload
```bash
uvicorn labs.lab09_file_upload:app --reload
curl -F "file=@README.md" http://127.0.0.1:8000/upload
```

### Lab 10 template
```bash
uvicorn labs.lab10_templates_static:app --reload
# Visit http://127.0.0.1:8000/hello?name=World
```

### Lab 11 auth
```bash
uvicorn labs.lab11_auth_bearer:app --reload
curl -X POST http://127.0.0.1:8000/login -H "content-type: application/json" -d '{"username":"demo","password":"pass"}'
# Response contains: {"access_token":"secret123","token_type":"bearer"}
curl -H "Authorization: Bearer secret123" http://127.0.0.1:8000/me
```

### Lab 12 websockets
Run the server then open your browser devtools console:
```js
const ws = new WebSocket("ws://127.0.0.1:8000/ws");
ws.onmessage = e => console.log("server:", e.data);
ws.onopen = () => ws.send("hello");
```

---

## Testing
A couple of sample tests are included.
```bash
pytest -q
```

---

## Notes to Reviewer / Mentor
These labs were written to practice FastAPI fundamentals step-by-step:
- returning JSON
- path & query params
- Pydantic models (v2 style) and validation
- simple CRUD with in-memory storage
- dependencies (header-based token)
- custom exceptions & handlers
- background tasks
- middleware (CORS)
- file uploads
- templates & static files
- a very simple bearer auth
- basic websockets
- environment-driven settings
- modular routers / structure
- a stub ML prediction endpoint

They are intentionally small to show learning-in-progress rather than production code.
