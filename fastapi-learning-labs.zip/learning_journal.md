
# Learning Journal (FastAPI)

**Day 1** — Hello World & Parameters
- Built first FastAPI app (`lab01_hello_world.py`), returned JSON.
- Practiced path & query parameters (`lab02_path_query.py`).

**Day 2** — Pydantic & CRUD
- Created `Item` model with validation (`lab03_pydantic_models.py`).
- Implemented a small in-memory CRUD for todos (`lab04_crud_in_memory.py`).

**Day 3** — Dependencies, Errors, Tasks
- Header-based dependency for simple token check (`lab05_dependencies_headers.py`).
- Custom exception and global handler (`lab06_error_handling.py`).
- Background task to append to a log file (`lab07_background_tasks.py`).

**Day 4** — Middleware, Uploads, Templates
- Enabled permissive CORS to understand cross-origin (`lab08_cors_middleware.py`).
- Implemented file upload and saved to disk (`lab09_file_upload.py`).
- Rendered a Jinja2 template and mounted static files (`lab10_templates_static.py`).

**Day 5** — Auth, WebSockets, Settings
- Basic bearer-style auth (demo-only) (`lab11_auth_bearer.py`).
- WebSocket echo server (`lab12_websockets.py`).
- Read settings from environment variables (`lab13_settings_env.py`).

**Day 6** — Structure & ML Stub
- Split routes into modules with `include_router` (`lab14_router_structure/`).
- Minimal ML-like predict endpoint returning a numeric result (`lab15_ml_stub.py`).
