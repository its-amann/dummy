
from fastapi import FastAPI, WebSocket, WebSocketDisconnect

app = FastAPI(title="Lab 12 - WebSockets Echo")

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    await ws.send_text("Connected. Send 'bye' to close.")
    try:
        while True:
            text = await ws.receive_text()
            if text.lower() == "bye":
                await ws.send_text("Goodbye!")
                await ws.close()
                break
            await ws.send_text(f"echo: {text}")
    except WebSocketDisconnect:
        pass
