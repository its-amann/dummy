
from fastapi import FastAPI, BackgroundTasks
from datetime import datetime
from pathlib import Path

app = FastAPI(title="Lab 07 - Background Tasks")
LOG_PATH = Path(__file__).parent / "data" / "emails.log"
LOG_PATH.parent.mkdir(parents=True, exist_ok=True)

def write_log(email: str, message: str):
    ts = datetime.utcnow().isoformat()
    with LOG_PATH.open("a", encoding="utf-8") as f:
        f.write(f"{ts} -> to={email} msg={message}\n")

@app.post("/send-email")
def send_email(email: str, message: str, bg: BackgroundTasks):
    bg.add_task(write_log, email=email, message=message)
    return {"queued": True, "email": email}
