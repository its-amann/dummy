
from fastapi import APIRouter
from pydantic import BaseModel, Field

router = APIRouter(prefix="/users", tags=["users"])

class User(BaseModel):
    id: int
    name: str = Field(..., min_length=1)

USERS = {1: User(id=1, name="Alice")}

@router.get("/", response_model=list[User])
def list_users():
    return list(USERS.values())
