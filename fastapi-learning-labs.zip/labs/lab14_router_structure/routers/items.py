
from fastapi import APIRouter
from pydantic import BaseModel, Field

router = APIRouter(prefix="/items", tags=["items"])

class Item(BaseModel):
    id: int
    name: str = Field(..., min_length=1)

ITEMS = {1: Item(id=1, name="Book")}

@router.get("/", response_model=list[Item])
def list_items():
    return list(ITEMS.values())
