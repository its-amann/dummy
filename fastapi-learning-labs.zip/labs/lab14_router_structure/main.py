
from fastapi import FastAPI
from .routers import users, items

app = FastAPI(title="Lab 14 - Router Structure")
app.include_router(users.router)
app.include_router(items.router)

@app.get("/")
def root():
    return {"message": "Modular app using routers"}
