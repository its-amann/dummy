
from fastapi import FastAPI
from typing import Optional

app = FastAPI(title="Lab 02 - Path & Query Parameters")

@app.get("/items/{item_id}")
def read_item(item_id: int, q: Optional[str] = None, limit: int = 10):
    return {"item_id": item_id, "q": q, "limit": limit}
