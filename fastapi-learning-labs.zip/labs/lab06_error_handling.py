
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

app = FastAPI(title="Lab 06 - Error Handling")

class NotEnoughCoins(Exception):
    def __init__(self, user_id: str, coins: int):
        self.user_id = user_id
        self.coins = coins

@app.exception_handler(NotEnoughCoins)
async def not_enough_coins_handler(request: Request, exc: NotEnoughCoins):
    return JSONResponse(
        status_code=400,
        content={
            "error": "NotEnoughCoins",
            "user_id": exc.user_id,
            "coins": exc.coins,
            "hint": "Add funds to complete purchase."
        },
    )

@app.get("/buy")
def buy(user_id: str, price: int, coins: int):
    if coins < price:
        raise NotEnoughCoins(user_id, coins)
    return {"status": "purchased", "user_id": user_id, "price": price, "coins_left": coins - price}
