
from fastapi import FastAPI
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "My Learning App"
    debug: bool = False
    model_config = SettingsConfigDict(env_prefix="APP_", env_file=".env", extra="ignore")

settings = Settings()

app = FastAPI(title="Lab 13 - Settings from Environment")

@app.get("/config")
def config():
    return {"app_name": settings.app_name, "debug": settings.debug}
