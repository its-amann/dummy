
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

app = FastAPI(title="Lab 04 - In-Memory CRUD")

class TodoIn(BaseModel):
    title: str = Field(..., min_length=1)
    done: bool = False

class Todo(TodoIn):
    id: int

TODOS: Dict[int, Todo] = {}
COUNTER = 0

def next_id() -> int:
    global COUNTER
    COUNTER += 1
    return COUNTER

@app.get("/todos", response_model=List[Todo])
def list_todos():
    return list(TODOS.values())

@app.post("/todos", response_model=Todo, status_code=201)
def create_todo(todo: TodoIn):
    tid = next_id()
    new = Todo(id=tid, **todo.model_dump())
    TODOS[tid] = new
    return new

@app.get("/todos/{todo_id}", response_model=Todo)
def get_todo(todo_id: int):
    if todo_id not in TODOS:
        raise HTTPException(status_code=404, detail="Todo not found")
    return TODOS[todo_id]

@app.put("/todos/{todo_id}", response_model=Todo)
def update_todo(todo_id: int, todo: TodoIn):
    if todo_id not in TODOS:
        raise HTTPException(status_code=404, detail="Todo not found")
    updated = Todo(id=todo_id, **todo.model_dump())
    TODOS[todo_id] = updated
    return updated

@app.delete("/todos/{todo_id}", status_code=204)
def delete_todo(todo_id: int):
    if todo_id not in TODOS:
        raise HTTPException(status_code=404, detail="Todo not found")
    del TODOS[todo_id]
