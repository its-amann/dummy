
from fastapi import FastAPI, UploadFile, File
from pathlib import Path

app = FastAPI(title="Lab 09 - File Upload")

UPLOAD_DIR = Path(__file__).parent / "data" / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    dest = UPLOAD_DIR / file.filename
    contents = await file.read()
    dest.write_bytes(contents)
    return {"filename": file.filename, "size": len(contents), "saved_to": str(dest)}
