
from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List

app = FastAPI(title="Lab 03 - Pydantic Models")

class Item(BaseModel):
    name: str = Field(..., min_length=1, max_length=50)
    price: float = Field(..., gt=0)
    is_offer: bool = Field(default=False)
    tags: List[str] = Field(default_factory=list)

@app.post("/items")
def create_item(item: Item):
    # Pydantic v2: use model_dump()
    return {"id": 1, "item": item.model_dump()}
