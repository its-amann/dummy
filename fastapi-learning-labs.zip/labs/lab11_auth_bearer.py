
from fastapi import FastAPI, HTTPException, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

app = FastAPI(title="Lab 11 - Simple Bearer Auth (Demo Only)")

security = HTTPBearer(auto_error=False)

class Login(BaseModel):
    username: str
    password: str

FAKE_DB = {"demo": "pass"}
FAKE_TOKEN = "secret123"

@app.post("/login")
def login(payload: Login):
    if FAKE_DB.get(payload.username) == payload.password:
        return {"access_token": FAKE_TOKEN, "token_type": "bearer"}
    raise HTTPException(status_code=401, detail="Bad credentials")

def get_current_user(credentials: HTTPAuthorizationCredentials = Security(security)):
    if not credentials or credentials.scheme.lower() != "bearer":
        raise HTTPException(status_code=401, detail="Not authenticated")
    token = credentials.credentials
    if token != FAKE_TOKEN:
        raise HTTPException(status_code=403, detail="Invalid token")
    return {"username": "demo"}

@app.get("/me")
def me(user = Security(get_current_user)):
    return {"user": user}
