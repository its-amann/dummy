
from fastapi import FastAPI, Depends, Header, HTTPException

app = FastAPI(title="Lab 05 - Dependencies (Headers)")

async def verify_token(x_token: str = Header(..., alias="X-Token")):
    if x_token != "learnfast":
        raise HTTPException(status_code=401, detail="Invalid or missing X-Token")
    return x_token

@app.get("/public")
def public_ping():
    return {"status": "ok", "scope": "public"}

@app.get("/private")
def private_ping(token: str = Depends(verify_token)):
    return {"status": "ok", "scope": "private", "token": token}
