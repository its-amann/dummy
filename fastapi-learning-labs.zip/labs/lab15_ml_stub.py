
from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List

app = FastAPI(title="Lab 15 - ML Stub Endpoint")

class PredictIn(BaseModel):
    features: List[float] = Field(..., min_length=1)

class PredictOut(BaseModel):
    prediction: float
    details: dict

def dummy_model(features: List[float]) -> float:
    # Minimal 'model': average of features (just for demo)
    return sum(features) / len(features)

@app.post("/predict", response_model=PredictOut)
def predict(payload: PredictIn):
    y = dummy_model(payload.features)
    return PredictOut(prediction=y, details={"n_features": len(payload.features)})
